/* ═══════════════════════════════════════════
   DASHBOARD — app.js
   ═══════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ─────────────────────────────────────────
     1. SIDEBAR — collapse (desktop) / drawer (mobile)
  ───────────────────────────────────────── */
  const sidebar              = document.getElementById('sidebar');
  const sidebarToggle        = document.getElementById('sidebarToggle');
  const mobileSidebarToggle  = document.getElementById('mobileSidebarToggle');
  const sidebarOverlay       = document.getElementById('sidebarOverlay');

  const isMobile = () => window.innerWidth <= 768;

  sidebarToggle.addEventListener('click', () => {
    if (isMobile()) {
      // On mobile, the in-sidebar button closes the drawer
      sidebar.classList.remove('mobile-open');
      sidebarOverlay.classList.remove('active');
    } else {
      // On desktop, toggle collapsed
      sidebar.classList.toggle('collapsed');
      positionUserPopover();
    }
  });

  mobileSidebarToggle.addEventListener('click', () => {
    sidebar.classList.add('mobile-open');
    sidebarOverlay.classList.add('active');
  });

  sidebarOverlay.addEventListener('click', () => {
    sidebar.classList.remove('mobile-open');
    sidebarOverlay.classList.remove('active');
  });

  // On resize: clear mobile state if going desktop
  window.addEventListener('resize', () => {
    if (!isMobile()) {
      sidebar.classList.remove('mobile-open');
      sidebarOverlay.classList.remove('active');
    }
    positionUserPopover();
    // Re-measure open accordions
    document.querySelectorAll('.nav-accordion.open').forEach(acc => {
      const content = acc.querySelector('.nav-accordion-content');
      content.style.height = content.scrollHeight + 'px';
    });
  });


  /* ─────────────────────────────────────────
     2. SIDEBAR ACCORDIONS
  ───────────────────────────────────────── */
  document.querySelectorAll('.nav-accordion').forEach(accordion => {
    const trigger = accordion.querySelector('.nav-accordion-trigger');
    const content = accordion.querySelector('.nav-accordion-content');
    content.style.height = '0px';

    trigger.addEventListener('click', () => {
      const isOpen = accordion.classList.contains('open');

      // Close all others
      document.querySelectorAll('.nav-accordion.open').forEach(other => {
        if (other !== accordion) {
          other.classList.remove('open');
          other.querySelector('.nav-accordion-content').style.height = '0px';
        }
      });

      if (isOpen) {
        accordion.classList.remove('open');
        content.style.height = '0px';
      } else {
        accordion.classList.add('open');
        content.style.height = content.scrollHeight + 'px';
      }
    });
  });


  /* ─────────────────────────────────────────
     3. USER POPOVER (sidebar)
        - Sidebar expanded  → above the user-card
        - Sidebar collapsed → to the right of the sidebar
  ───────────────────────────────────────── */
  const userCardTrigger = document.getElementById('userCardTrigger');
  const userPopover     = document.getElementById('userPopover');

  function positionUserPopover() {
    const isCollapsed = sidebar.classList.contains('collapsed');
    const sidebarRect = sidebar.getBoundingClientRect();
    const cardRect    = userCardTrigger.getBoundingClientRect();

    if (isCollapsed) {
      // Position to the RIGHT of the sidebar, aligned with the card vertically
      userPopover.style.left   = (sidebarRect.right + 8) + 'px';
      userPopover.style.bottom = (window.innerHeight - cardRect.bottom - 4) + 'px';
      userPopover.style.top    = 'auto';
    } else {
      // Position ABOVE the user-card, inside the sidebar column
      userPopover.style.left   = sidebarRect.left + 8 + 'px';
      userPopover.style.bottom = (window.innerHeight - cardRect.top + 8) + 'px';
      userPopover.style.top    = 'auto';
    }
  }

  userCardTrigger.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = userPopover.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      positionUserPopover();
      userPopover.classList.add('open');
    }
  });


  /* ─────────────────────────────────────────
     4. USER POPOVER — topbar avatar
  ───────────────────────────────────────── */
  const topbarAvatarBtn   = document.getElementById('topbarAvatarBtn');
  const topbarUserPopover = document.getElementById('topbarUserPopover');

  topbarAvatarBtn.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = topbarUserPopover.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) topbarUserPopover.classList.add('open');
  });


  /* ─────────────────────────────────────────
     5. NOTIFICATIONS
  ───────────────────────────────────────── */
  const notifBtn      = document.getElementById('notifBtn');
  const notifDropdown = document.getElementById('notifDropdown');
  const notifDot      = document.getElementById('notifDot');
  const markAllRead   = document.getElementById('markAllRead');

  updateNotifDot();

  notifBtn.addEventListener('click', e => {
    e.stopPropagation();
    const isOpen = notifDropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) notifDropdown.classList.add('open');
  });

  markAllRead.addEventListener('click', e => {
    e.stopPropagation();
    document.querySelectorAll('.notif-item.unread').forEach(item => {
      item.classList.remove('unread');
      item.querySelector('.notif-unread-dot')?.remove();
    });
    updateNotifDot();
    showToast('Notifications', 'All notifications marked as read.', 'success');
  });

  document.querySelectorAll('.notif-item').forEach(item => {
    item.addEventListener('click', () => {
      item.classList.remove('unread');
      item.querySelector('.notif-unread-dot')?.remove();
      updateNotifDot();
      notifDropdown.classList.remove('open');
    });
  });

  function updateNotifDot() {
    const unread = document.querySelectorAll('.notif-item.unread').length;
    notifDot.classList.toggle('active', unread > 0);
  }


  /* ─────────────────────────────────────────
     6. THEME TOGGLE — header button + sidebar popover button
  ───────────────────────────────────────── */
  const htmlEl = document.documentElement;

  // Restore persisted theme
  const savedTheme = localStorage.getItem('theme') || 'dark';
  if (savedTheme === 'light') {
    htmlEl.classList.remove('dark');
    htmlEl.classList.add('light');
  }

  function applyThemeToggle() {
    if (htmlEl.classList.contains('dark')) {
      htmlEl.classList.replace('dark', 'light');
      localStorage.setItem('theme', 'light');
      showToast('Theme', 'Switched to light mode.', 'info');
    } else {
      htmlEl.classList.replace('light', 'dark');
      localStorage.setItem('theme', 'dark');
      showToast('Theme', 'Switched to dark mode.', 'info');
    }
  }

  document.getElementById('themeToggleHeader').addEventListener('click', applyThemeToggle);
  document.getElementById('themeToggle').addEventListener('click', applyThemeToggle);


  /* ─────────────────────────────────────────
     7. CLOSE ALL DROPDOWNS on outside click / Escape
  ───────────────────────────────────────── */
  const allDropdowns = [userPopover, topbarUserPopover, notifDropdown];

  function closeAllDropdowns() {
    allDropdowns.forEach(d => d.classList.remove('open'));
  }

  document.addEventListener('click', closeAllDropdowns);
  allDropdowns.forEach(d => d.addEventListener('click', e => e.stopPropagation()));

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeAllDropdowns();
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault();
      document.getElementById('topbarSearchInput')?.focus();
    }
  });


  /* ─────────────────────────────────────────
     8. TOAST SYSTEM
  ───────────────────────────────────────── */
  function showToast(title, description, type = 'info') {
    const container = document.getElementById('toastContainer');
    const icons = {
      success: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="hsl(142 71% 45%)" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>`,
      error:   `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="hsl(0 72% 51%)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
      info:    `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="hsl(220 70% 50%)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
    };

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || icons.info}</span>
      <div class="toast-body">
        <div class="toast-title">${title}</div>
        <div class="toast-desc">${description}</div>
      </div>
      <button class="toast-close" aria-label="Close">×</button>
    `;
    container.appendChild(toast);

    const close = () => {
      toast.classList.add('removing');
      toast.addEventListener('animationend', () => toast.remove(), { once: true });
    };
    toast.querySelector('.toast-close').addEventListener('click', close);
    setTimeout(close, 4000);
  }
  window.showToast = showToast;


  /* ─────────────────────────────────────────
     9. WELCOME TOAST
  ───────────────────────────────────────── */
  setTimeout(() => {
    showToast('Welcome back, Jean 👋', 'You have 2 unread notifications.', 'info');
  }, 600);

});
